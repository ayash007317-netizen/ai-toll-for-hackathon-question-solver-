const API_URL = "https://api-integrations.appmedo.com/app-7w4mks13jz7l/api-rLob8RdzAOl9/v1beta/models/gemini-2.5-flash:streamGenerateContent?alt=sse";
const APP_ID = "app-7w4mks13jz7l";

export interface AIMessage {
  role: "user" | "model";
  parts: Array<{ text: string }>;
}

export interface AIRequest {
  contents: AIMessage[];
}

export async function* streamAIResponse(messages: AIMessage[]): AsyncGenerator<string> {
  const response = await fetch(API_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-App-Id": APP_ID,
    },
    body: JSON.stringify({
      contents: messages,
    }),
  });

  if (!response.ok) {
    throw new Error(`API request failed: ${response.statusText}`);
  }

  const reader = response.body?.getReader();
  if (!reader) {
    throw new Error("Response body is not readable");
  }

  const decoder = new TextDecoder();
  let buffer = "";

  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split("\n");
      buffer = lines.pop() || "";

      for (const line of lines) {
        if (line.startsWith("data: ")) {
          const data = line.slice(6);
          if (data === "[DONE]") continue;

          try {
            const parsed = JSON.parse(data);
            const text = parsed.candidates?.[0]?.content?.parts?.[0]?.text;
            if (text) {
              yield text;
            }
          } catch (e) {
            console.error("Failed to parse SSE data:", e);
          }
        }
      }
    }
  } finally {
    reader.releaseLock();
  }
}

export const PROMPTS = {
  problemAnalysis: (problem: string) => `You are an expert hackathon mentor. Analyze the following hackathon problem statement and provide:

1. **Problem Understanding**: Summarize the core problem
2. **Key Requirements**: List all important requirements
3. **Constraints**: Identify any constraints or limitations
4. **Expected Output**: What the solution should deliver

Problem Statement:
${problem}

Provide a clear, structured analysis.`,

  solutionIdeas: (problem: string) => `Based on this hackathon problem, generate 3 unique and innovative solution ideas:

Problem: ${problem}

For each solution, provide:
1. **Solution Name**: A catchy name
2. **Core Concept**: Main idea in 2-3 sentences
3. **Innovation Points**: What makes it unique
4. **Real-world Impact**: How it helps users
5. **Feasibility**: Quick assessment (Easy/Medium/Hard)

Make the solutions creative and practical.`,

  techStack: (problem: string, solution: string) => `Recommend a complete tech stack for this hackathon project:

Problem: ${problem}
Solution Approach: ${solution}

Provide recommendations for:
1. **Frontend**: Framework and libraries
2. **Backend**: Language and framework
3. **Database**: Type and specific database
4. **Cloud Services**: Hosting and services (Firebase, AWS, Azure, etc.)
5. **APIs & Libraries**: Relevant third-party services
6. **Development Tools**: Essential tools

Explain why each choice is suitable for a hackathon (quick development, good documentation, etc.).`,

  architecture: (problem: string, techStack: string) => `Design the system architecture for this hackathon project:

Problem: ${problem}
Tech Stack: ${techStack}

Provide:
1. **System Architecture**: High-level component diagram description
2. **Frontend Flow**: User interface flow
3. **Backend Flow**: API and data processing flow
4. **Database Schema**: Key tables/collections and relationships
5. **API Design**: Main endpoints and their purposes
6. **Data Flow**: How data moves through the system

Use clear descriptions that can be visualized.`,

  codeGeneration: (problem: string, techStack: string, architecture: string) => `Generate starter code for this hackathon project:

Problem: ${problem}
Tech Stack: ${techStack}
Architecture: ${architecture}

Provide:
1. **Frontend Code**: Main component structure with sample code
2. **Backend Code**: API endpoints with sample implementation
3. **Database Schema**: Complete schema definition
4. **Configuration**: Environment setup and config files
5. **Integration**: How components connect

Include comments explaining key parts. Keep code practical and hackathon-ready.`,

  stepByStep: (problem: string, solution: string) => `Create a step-by-step implementation guide for this hackathon project:

Problem: ${problem}
Solution: ${solution}

Provide:
1. **Setup Phase** (30 mins): Initial project setup
2. **Core Features** (3-4 hours): Priority features to build first
3. **Integration** (1-2 hours): Connecting components
4. **Testing** (30 mins): Quick testing approach
5. **Polish** (1 hour): UI/UX improvements
6. **Presentation Prep** (30 mins): Demo preparation tips

Include time estimates and prioritization advice.`,

  presentation: (problem: string, solution: string, features: string) => `Create a hackathon presentation outline:

Problem: ${problem}
Solution: ${solution}
Key Features: ${features}

Generate content for:
1. **Title Slide**: Project name and tagline
2. **Problem Statement**: Why this matters
3. **Solution Overview**: Your approach
4. **Key Features**: 3-5 main features with descriptions
5. **Tech Stack**: Technologies used
6. **Demo Flow**: Step-by-step demo script
7. **Impact**: Real-world benefits
8. **Future Enhancements**: What's next
9. **Team Slide**: Roles and contributions

Make it compelling and judge-friendly!`,
};
